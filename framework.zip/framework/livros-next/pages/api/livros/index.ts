import { NextApiRequest, NextApiResponse } from "next";
import { ControleLivro } from "../../../classes/controle/ControleLivro";
import { Livro } from "../../../classes/modelo/Livro";

export const controleLivro = new ControleLivro();

// eslint-disable-next-line import/no-anonymous-default-export
export default (req: NextApiRequest, res: NextApiResponse) => {
  if (req.statusCode === 405) {
    return res.status(405).json({ message: "Método não permitido" });
  }

  if (req.statusCode === 500) {
    return res.status(500).json({ message: "Erro interno no servidor" });
  }

  if (req.method === "GET") {
    return res.status(200).json(controleLivro.obterLivros());
  }

  if (req.method === "POST") {
    const { codigo, codEditora, titulo, resumo, autores } = req.body;
    const livro = new Livro(codigo, codEditora, titulo, resumo, autores);

    return res.status(200).json(controleLivro.incluir(livro));
  }
};

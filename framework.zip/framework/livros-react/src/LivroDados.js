import { useState } from "react";
import { ControleEditora } from "./controle/ControleEditora";
import { ControleLivro } from "./controle/ControleLivro"
import { useNavigate } from "react-router-dom";
import { Livro } from "./modelo/Livro";

const controleLivro = new ControleLivro();
const controleEditora = new ControleEditora();

export default function LivroDados(){
  const navigate = useNavigate();
  
  const opcoes = controleEditora.getEditoras().map(editora => ({
    value: editora.codEditora,
    text: editora.nome
  }));
  const [titulo, setTitulo] = useState('');
  const [resumo, setResumo] = useState('');
  const [autores, setAutores] = useState('');
  const [codEditora, setCodEditora] = useState(opcoes[0].value);

  function tratarCombo(event){
    setCodEditora(Number(event.target.value));
  }

  function incluir(event){
    event.preventDefault();
    const livro = new Livro(0, codEditora, titulo, resumo, autores.split('\n'));
    controleLivro.incluir(livro);
    navigate('/');
  }

  return (
    <main className="container">
      <h1>Dados do livro</h1>
      <form onSubmit={incluir}>
        <div className="form-group mb-2">
          <label htmlFor="titulo">Título</label>
          <input type="text" className="form-control" id="titulo" value={titulo} onChange={(event) => setTitulo(event.target.value)} />
        </div>
        <div className="form-group mb-2">
          <label htmlFor="resumo">Resumo</label>
          <textarea className="form-control" id="resumo" value={resumo} onChange={(event) => setResumo(event.target.value)} />
        </div>
        <div className="form-group mb-2">
          <label htmlFor="editora">Editora</label>
          <select className="form-control" id="editora" value={codEditora} onChange={tratarCombo}>
            {opcoes.map(opcao => (
              <option key={opcao.value} value={opcao.value}>{opcao.text}</option>
            ))}
          </select>
        </div>
        <div className="form-group mb-2">
          <label htmlFor="autores">Autores (1 por linha)</label>
          <textarea rows={3} type="text" className="form-control" id="autores" value={autores} onChange={(event) => setAutores(event.target.value)} />
        </div>
        <button type="submit" className="btn btn-primary">Salvar dados</button>
      </form>
    </main>
  )
}
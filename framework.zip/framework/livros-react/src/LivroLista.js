import { useEffect, useState } from "react";
import { ControleEditora } from "./controle/ControleEditora";
import { ControleLivro } from "./controle/ControleLivro";

const controleLivro = new ControleLivro();
const controleEditora = new ControleEditora();

function LinhaLivro(props) {
  const excluir = props.excluir;
  const livro = props.livro;
  const nomeEditora = controleEditora.getNomeEditora(livro.codEditora)

  return (
    <tr>  
      <td>
        <span>
          {livro.titulo}  
        </span>
        <br />
        <button onClick={() => excluir(livro.codigo)} className="btn btn-danger">
          Excluir
        </button>
      </td>
      <td>{livro.resumo}</td>
      <td>{nomeEditora}</td>
      <td>
        <ul>
          {livro.autores.map((autor, index) => (
            <li key={index}>{autor}</li>
          ))}
        </ul>
      </td>
    </tr>
  )
}

export default function LivroLista() {
  const [livros, setLivros] = useState();
  const [carregado, setCarregado] = useState(false);

  useEffect(() => {
    const livros = controleLivro.obterLivros();
    setLivros(livros);
    setCarregado(true);
  }, [carregado]);

  const excluir = (codigo) => {
    controleLivro.excluir(codigo);
    setCarregado(false);
  }

  return (
    <main className="container">
      <h1>Catálogo de Livros</h1>
      <table className="table table-striped">
        <thead className="thead-dark bg-info">
          <tr className="bg-info">
            <th scope="col" className="bg-dark text-white">Título</th>
            <th scope="col" className="bg-dark text-white">Resumo</th>
            <th scope="col" className="bg-dark text-white">Editora</th>
            <th scope="col" className="bg-dark text-white">Autores</th>
          </tr>
        </thead>
        <tbody>
          {livros && livros.map((livro, index) => (
            <LinhaLivro key={index} livro={livro} excluir={excluir} />
          ))}
        </tbody>
      </table>
    </main>
  )
}
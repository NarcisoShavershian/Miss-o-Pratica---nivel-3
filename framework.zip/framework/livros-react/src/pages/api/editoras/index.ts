import { ControleEditora } from "../../../controle/ControleEditora";

export const controleEditora = new ControleEditora();
